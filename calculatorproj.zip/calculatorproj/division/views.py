from django.shortcuts import render
from django.http import HttpResponse


def div(request):
    a, b = 20, 10
    return HttpResponse('division is ' + str(a / b))
# Create your views here.
