from django.shortcuts import render
from django.http import HttpResponse


def subs(request):
    a, b = 20, 10
    return HttpResponse("substraction is " + str(a - b))

# Create your views here.
