from django.shortcuts import render
from django.http import HttpResponse


def add(request):
    a, b = 10, 20
    return HttpResponse("addition is "+str(a+b))
# Create your views here.
